<script>
    $(document).ready(function() {
        function setNumberOfPostsInARow(numberOfPosts) {
            var bspPost = $('.bsp_inspect_search_results>.bsp-post');
            switch (numberOfPosts) {
                case 1:
                    bspPost.addClass("col-lg-10 col-md-10");
                    bspPost.css('margin-right', '45px');
                    break
                case 2:
                    bspPost.addClass("col-lg-5 col-md-5");
                    bspPost.css('margin-right', '45px');
                    break
                case 3:
                    bspPost.addClass("col-lg-3 col-md-3");
                    bspPost.css('margin-right', '45px');
                    break
                case 4:
                    bspPost.addClass("col-lg-3 col-md-3");
                    bspPost.css('margin', '0');
                    //bspPost.css('height', 'auto');
                    break
                case 5:
                    bspPost.addClass("col-lg-2 col-md-3");
                    bspPost.css('height', 'auto');
                    break
            }
        }
        setNumberOfPostsInARow(<?php echo get_option('bsp_inspect_posts_in_row'); ?>);
    });
</script>