<?php
function bsp_inspect_search($form)
{
    $form = '';
    ?>
    <div class="bsp_inspect_search_container">
        <a class='bsp_inspect_search'><img
                src="" alt=""></a>

        <div class='bsp_inspect_container'>
            <div class='row header_elements'>
                <div class='col-lg-2 col-md-2 col-sm-2'>
                    <span class='bsp_inspect_label'>Search</span>
                </div>
                <div class='col-lg-9 col-md-9 col-sm-9'>
                    <a class='bsp_inspect_all_results' href="<?php bloginfo('url') ?>">All results</a>
                </div>
                <div class='col-lg-1 col-md-1 col-sm-1'>
                    <a class='bsp_inspect_close'><img
                            src="<?php echo plugins_url(); ?>/bsp_inspect/assets/img/close_btn.png" alt=""></a>
                </div>
            </div>
            <input class='bsp_inspect_search_field' type='text'>

            <div class="preloader">
                <img src="" alt="">
            </div>
            <div class='bsp_inspect_search_results'></div>
        </div>
    </div>
    <?php
    return $form;
}

function postStructure($query)
{
    if($query == null) {
        ?>
        <h3 class='bsp_inspect_no_results'><?php echo get_option('bsp_inspect_no_results_text') ?></h3>
        <?php
        return;
    }

    if ($query->have_posts()) {

        while ($query->have_posts()) {
            $query->the_post();
            ?>

            <div class='bsp-post'>
                <a href="<?php echo the_permalink(); ?>">
                    <div class='bsp-thumbnail-container'>
                        <?php $url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID())); ?>
                        <img class='bsp-thumbnail' src="<?php echo $url; ?>">
                    </div>
                    <div class='bsp-over-info'>
                        <span class='bsp-author'><?php echo get_the_author(); ?></span>
                        <span class='bsp-date'><?php echo get_the_date(); ?></span>
                    </div>
                    <div class='bsp-title'><?php echo the_title(); ?></div>
                </a>
            </div>

            <?php
        }
    }
}

?>