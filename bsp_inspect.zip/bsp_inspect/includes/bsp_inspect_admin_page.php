<?php

function bsp_inspect_add_admin_page()
{

    add_options_page("BSPInspect Search", "BSPInspect Search", 8, "bsp_inspect_search", "bsp_inspect_options_page");

}

add_action('admin_menu', 'bsp_inspect_add_admin_page');

function bsp_inspect_options_page()
{
    add_option("bsp_inspect_background", "rgba(0, 0, 0, 0.85)");
    add_option("bsp_inspect_font_color", "#fff");
    add_option("bsp_inspect_icon", '" . plugins_url() . "/bsp_inspect/assets/img/search-icon(black).png');
    add_option("bsp_inspect_preloader", '" . plugins_url() . "/bsp_inspect/assets/img/preloaders/preloader(circle).gif');
    add_option("bsp_inspect_font", 'Arial');
    add_option("bsp_inspect_pages", "30");
    add_option("bsp_inspect_search_text", "Search");
    add_option("bsp_inspect_no_results_text", "No results");
    add_option("bsp_inspect_all_results_text", "All results");
    add_option("bsp_inspect_posts_in_row", "5");

    echo "<h2 style='text-align: center'>BSPInspect Options Page</h2>";
    general_options();


}

add_action('wp_footer', 'update_css');

//changing website page
function update_css()
{
    ?>
    <script type="text/javascript">

        $(document).ready(function () {

            function setIconAndPreloader() {
                var icon = "<?php echo get_option('bsp_inspect_icon'); ?>";
                var preloader = "<?php echo get_option('bsp_inspect_preloader'); ?>";

                $('.bsp_inspect_search>img').attr("src", icon);
                $('.preloader>img').attr("src", preloader);
            }

            function setBackground() {
                $('.bsp_inspect_search_container>.bsp_inspect_container').css('background', '<?php echo get_option('bsp_inspect_background'); ?>');
            }

            function setFontColor() {

                var all_results_btn = $('.bsp_inspect_search_container>.bsp_inspect_container>.header_elements .bsp_inspect_all_results');

                $('.bsp_inspect_search_container>.bsp_inspect_container').css('color', '<?php echo get_option('bsp_inspect_font_color'); ?>');

                all_results_btn.css('cssText', 'color: <?php echo get_option('bsp_inspect_font_color'); ?> !important;');
                all_results_btn.css('border-color', '<?php echo get_option('bsp_inspect_font_color'); ?>');
                $('.bsp_inspect_search_container>.bsp_inspect_container>.bsp_inspect_search_field').css('color', '<?php echo get_option('bsp_inspect_font_color'); ?>');
                //$('.bsp_inspect_search_container>.bsp_inspect_container>.bsp_inspect_search_results>.bsp_inspect_no_results').css('color', '<?php echo get_option('bsp_inspect_font_color'); ?>');
                $('.bsp_inspect_search_results').css('color', '<?php echo get_option('bsp_inspect_font_color'); ?>');
            }

            function setFontFamily() {
                $('.bsp_inspect_search_container>.bsp_inspect_container').css('font-family', '<?php echo get_option('bsp_inspect_font'); ?>');
                $('.bsp_inspect_search_container>.bsp_inspect_container>.bsp_inspect_search_field').css('font-family', '<?php echo get_option('bsp_inspect_font'); ?>');
                $('.bsp_inspect_search_results').css('font-family', '<?php echo get_option('bsp_inspect_font'); ?>');
            }

            function setText() {
                $('.bsp_inspect_label').text("<?php echo get_option('bsp_inspect_search_text'); ?>");
                $('.bsp_inspect_all_results').text("<?php echo get_option('bsp_inspect_all_results_text'); ?>");
            }



            setIconAndPreloader();
            setBackground();
            setFontColor();
            setFontFamily();
            setText();


        });
    </script>
    <?php
}


function general_options()
{

    if (isset($_POST['bsp_inspect_setup_btn'])) {

        $background = $_POST['bsp_inspect_background'];
        $font_color = $_POST['bsp_inspect_font_color'];
        $icon = $_POST['bsp_inspect_icon'];
        $preloader = $_POST['bsp_inspect_preloader'];
        $font = $_POST['bsp_inspect_font'];
        $pages = $_POST['bsp_inspect_pages'];
        $search_text = $_POST['bsp_inspect_search_text'];
        $no_results_text = $_POST['bsp_inspect_no_results_text'];
        $all_results_text = $_POST['bsp_inspect_all_results_text'];
        $posts_in_row = $_POST['bsp_inspect_posts_in_row'];

        update_option('bsp_inspect_background', $background);
        update_option('bsp_inspect_font_color', $font_color);
        update_option('bsp_inspect_icon', $icon);
        update_option('bsp_inspect_preloader', $preloader);
        update_option('bsp_inspect_font', $font);
        update_option('bsp_inspect_pages', $pages);
        update_option('bsp_inspect_search_text', $search_text);
        update_option('bsp_inspect_no_results_text',$no_results_text);
        update_option('bsp_inspect_all_results_text',$all_results_text);
        update_option('bsp_inspect_posts_in_row',$posts_in_row);

    }

    echo "
    <div class='container'>
    <ul class='nav nav-tabs'>
            <li class='active'><a data-toggle='tab' href='#general'>General</a></li>
            <li><a data-toggle='tab' href='#color'>Color</a></li>
            <li><a data-toggle='tab' href='#images'>Images</a></li>
            <li><a data-toggle='tab' href='#text'>Text</a></li>
        </ul>
    <form name='bsp_inspect_base_setup' method='POST' action='" . $_SERVER['PHP_SELF'] . "?page=bsp_inspect_search&amp;updated=true' role='form'>
        <div class='tab-content'>
        <div id='general' class='tab-pane fade in active'>
            <label class='form-group' style='display: block'>Number of posts in a row
            <select class='form-control' name='bsp_inspect_posts_in_row' id='bsp_inspect_posts_in_row'>
                <option value='1'>1</option>
                <option value='2'>2</option>
                <option value='3'>3</option>
                <option value='4'>4</option>
                <option value='5'>5</option>
            </select></label>
            <label class='form-group'>Number of pages
                <input name='bsp_inspect_pages' type='text' value='" . get_option('bsp_inspect_pages') . "' class='form-control' />
            </label>
        </div>
        <div id='color' class='tab-pane fade'>
            <label class='form-group'>Background
            <div class='input-group background_picker' name=>
                <input name='bsp_inspect_background' type='text' value='" . get_option('bsp_inspect_background') . "' class='form-control' />
                <span class='input-group-addon'><i></i></span>
            </div>
            </label>
            <label class='form-group'>Font Color
            <div class='input-group color_picker' name=>
                <input name='bsp_inspect_font_color' type='text' value='" . get_option('bsp_inspect_font_color') . "' class='form-control' />
                <span class='input-group-addon'><i></i></span>
            </div>
            </label>
        </div>
        <div id='images' class='tab-pane fade'>
            <label class='form-group' style='display: block'>Color of the loupe
            <select class='form-control' name='bsp_inspect_icon' id='bsp_inspect_icon'>
                <option value='" . plugins_url() . "/bsp_inspect/assets/img/search-icon(black).png'>black</option>
                <option value='" . plugins_url() . "/bsp_inspect/assets/img/search.png'>white</option>
            </select></label>
            <label class='form-group' style='display: block'>Preloaders
            <select class='form-control' name='bsp_inspect_preloader' id='bsp_inspect_preloader'>
                <option value='" . plugins_url() . "/bsp_inspect/assets/img/preloaders/preloader(trapeze).gif'>trapeze</option>
                <option value='" . plugins_url() . "/bsp_inspect/assets/img/preloaders/preloader(circle).gif'>circle</option>
                <option value='" . plugins_url() . "/bsp_inspect/assets/img/preloaders/preloader.gif'>preloader</option>
            </select>
            </label>
        </div>
        <div id='text' class='tab-pane fade'>
            <label class='form-group' style='display: block'>Fonts
            <select class='form-control' name='bsp_inspect_font' id='bsp_inspect_font'>
                <option value='Kavoon'>Kavoon</option>
                <option value='Times New Roman'>Times New Roman</option>
                <option value='Abel'>Abel</option>
                <option value='Inconsolata'>Inconsolata</option>
                <option value='Pacifico'>Pacifico</option>
                <option value='Chewy'>Chewy</option>
            </select>
            </label>
            <label class='form-group' style='display: block'>Search Text
                <input name='bsp_inspect_search_text' type='text' value='" . get_option('bsp_inspect_search_text') . "' class='form-control' />
            </label>
            <label class='form-group' style='display: block'>No Results Text
                <input name='bsp_inspect_no_results_text' type='text' value='" . get_option('bsp_inspect_no_results_text') . "' class='form-control' />
            </label>
            <label class='form-group' style='display: block'>All Results Text
                <input name='bsp_inspect_all_results_text' type='text' value='" . get_option('bsp_inspect_all_results_text') . "' class='form-control' />
            </label>
        </div>
            <button class='btn btn-primary' type='submit' name='bsp_inspect_setup_btn' style='display: block'>Save</button>
        </div>
    </form>
    </div>
    ";
    ?>
    <script>
        //changing admin page
        $(document).ready(function() {
            $('#bsp_inspect_icon option[value="<?php echo get_option('bsp_inspect_icon') ?>"]').attr('selected', 'selected');
            $('#bsp_inspect_preloader option[value="<?php echo get_option('bsp_inspect_preloader') ?>"]').attr('selected', 'selected');
            $('#bsp_inspect_font option[value="<?php echo get_option('bsp_inspect_font') ?>"]').attr('selected', 'selected');
            $('#bsp_inspect_posts_in_row option[value="<?php echo get_option('bsp_inspect_posts_in_row') ?>"]').attr('selected', 'selected');
            $('.background_picker').colorpicker();
            $('.color_picker').colorpicker();
        });
    </script>
    <?php
}




