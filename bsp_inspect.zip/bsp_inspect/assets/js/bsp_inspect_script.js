$(document).ready(function() {
    var all_results_href = $(".bsp_inspect_all_results").attr('href');
    function bsp_inspect_init() {
        $(".bsp_inspect_search_results").html('');
        $(".preloader").hide();
    }

    //function all_search_results_on_click() {
    //    $(".bsp_inspect_all_results").click(function() {
    //        $('.bsp_inspect_all_results').attr('href',all_results_href);
    //    })
    //}

    $(".bsp_inspect_search, .bsp_inspect_close").click(function(){
        bsp_inspect_init();
        var searchField = $(".bsp_inspect_search_field");
        searchField.val("");
        $(".bsp_inspect_container").fadeToggle("fast");
        searchField.focus();
        $('body').css('overflow-y', 'hidden');
    });
    $(document).keyup(function(e) {
        if (e.keyCode == 27) {
            $(".bsp_inspect_container").fadeOut("fast");
        }
    });

        $(".bsp_inspect_search_field").on('input', function () {
            var div = $(".bsp_inspect_search_results");
            var substr = $(this).val();
            if($(".bsp_inspect_search_field").val() !== "") {
                $(".preloader").fadeIn();
            }
            div.hide();
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    'action': 'bsp_search_ajax_request',
                    'substr': substr,
                    'number_posts' : 0
                },
                success: function (data) {

                    // This outputs the result of the ajax request
                    setTimeout(function() {
                        $(".bsp_inspect_all_results").hide();
                        $(".preloader").fadeOut(function() {
                            div.html(data);
                            div.fadeIn();
                            //console.log(data);
                            if($(data).find('div').length !== 0 && $(".bsp_inspect_search_field").val() !== "") {
                                $(".bsp_inspect_all_results").each(function () {
                                    $(".bsp_inspect_all_results").attr('href', all_results_href);
                                    var _href = $(this).attr("href");
                                    $(this).attr("href", _href + '/search/' + substr);
                                });
                                $(".bsp_inspect_all_results").show();
                            }
                        });

                        //console.log($(data).find('div').length);
                    }, 200);

                },

            });
        });




    // This does the ajax request

});
