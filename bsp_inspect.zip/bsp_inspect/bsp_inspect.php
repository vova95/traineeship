<?php
/**
 * Plugin Name: bsp_inspect1
 * Plugin URI: http://vovazubenko.com
 * Description: This is a plugin that allows us to test Ajax functionality in WordPress
 * Version: 1.2
 * Author: Vladymyr Zubenko
 * Author URI: http://vovazubenko.com
 * License: GPL2
 */

//add path to admin-ajax.php
require "includes/bsp_inspect_admin_page.php";
require "includes/bsp_inspect_structure.php";

require 'includes/plugin-updates/plugin-update-checker.php';
$MyUpdateChecker = PucFactory::buildUpdateChecker(
    'http://localhost/wpsearch/wp-content/plugins/updates/info.json',
    __FILE__
);

//init ajaxurl
function pluginname_ajaxurl() {
    ?>
    <script type="text/javascript">
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    </script>
    <?php
}

//including scripts and styles
function bsp_inspect_add_scripts() {
    wp_register_script('bsp_inspect_jquery', plugins_url('assets/js/jquery.min.js', __FILE__));
    wp_register_script('bsp_inspect_script', plugins_url('assets/js/bsp_inspect_script.js', __FILE__));
    wp_enqueue_script('bsp_inspect_jquery');
    wp_enqueue_script('bsp_inspect_script');
}



function bsp_inspect_add_styles() {
    wp_register_style('bsp_inspect_bootstrap', plugins_url('assets/css/bootstrap.min.css', __FILE__));
    wp_register_style('bsp_inspect_style', plugins_url('assets/css/bsp_inspect_style.css', __FILE__));
    wp_enqueue_style('bsp_inspect_bootstrap');
    wp_enqueue_style('bsp_inspect_style');
}

//including admin scripts and styles
function admin_load_scripts() {
    wp_register_script('bsp_inspect_jquery_admin', plugins_url('assets/js/jquery.min.js', __FILE__));
    wp_register_script('bsp_inspect_colorpicker_admin', plugins_url('assets/js/colorpicker/dist/js/bootstrap-colorpicker.js', __FILE__));
    wp_register_script('bsp_inspect_bootstrapjs', plugins_url('assets/js/bootstrap.min.js', __FILE__));
    wp_enqueue_script('bsp_inspect_jquery_admin');
    wp_enqueue_script('bsp_inspect_colorpicker_admin');
    wp_enqueue_script('bsp_inspect_bootstrapjs');
}


function admin_load_styles()
{
    wp_register_style('bsp_inspect_bootstrap_admin', plugins_url('assets/css/bootstrap.min.css', __FILE__));
    wp_register_style('bsp_inspect_style_admin', plugins_url('assets/css/bsp_inspect_style.css', __FILE__));
    wp_register_style('bsp_inspect_colorpicker', plugins_url('assets/js/colorpicker/dist/css/bootstrap-colorpicker.min.css', __FILE__));
    wp_enqueue_style('bsp_inspect_bootstrap_admin');
    wp_enqueue_style('bsp_inspect_style_admin');
    wp_enqueue_style('bsp_inspect_colorpicker');
}


//giving response for ajax request
function bsp_search_ajax_request() {
    require "includes/update_css.php";
    // The $_REQUEST contains all the data sent via ajax
    if ( isset($_REQUEST) ) {

        $substr = $_REQUEST['substr'];
        $number_posts = $_REQUEST['number_posts'];

        if($substr == "") {
            echo "";
        } else {
            $args = array('s' => $substr, 'post_type' => 'post', 'posts_per_page' => 1);

            echo bsp_inspect_get_search_results($substr);
        }

    }

    die();
}

//getting posts from DB by substr
function bsp_inspect_get_search_results($substr) {

    global $wpdb;

    $table_posts = $wpdb->prefix . "posts";

    $pages = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT option_value FROM wp_options WHERE option_name='bsp_inspect_pages'", ''
        )
    );

    $mypostids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT $table_posts.ID FROM $table_posts WHERE $table_posts.post_title LIKE %s AND $table_posts.post_type LIKE 'post'
            LIMIT %d",
            "%" . $substr . "%",
            $pages->option_value
        )
    );

    if(!empty($mypostids)) {
        $args = array(
            'post__in' => $mypostids,
            'post_type' => 'post',
            'orderby' => 'title',
            'order' => 'asc',
            //'posts_per_page' => $pages->option_value
        );

        $res = new WP_Query($args);


        return postStructure($res);
    } else {
        return postStructure(null);
    }
}


function bsp_inspect_init() {

    //if(is_admin()) {
        add_action('admin_enqueue_scripts', 'admin_load_scripts');
        add_action('admin_head', 'admin_load_styles');
    //} else {
        add_action('get_search_form', 'bsp_inspect_search');

        add_action('wp_head','pluginname_ajaxurl');

        add_action( 'wp_enqueue_scripts', 'bsp_inspect_add_scripts' );
        add_action( 'wp_enqueue_scripts', 'bsp_inspect_add_styles' );

        add_action( 'wp_ajax_bsp_search_ajax_request', 'bsp_search_ajax_request' );
        add_action( 'wp_ajax_nopriv_bsp_search_ajax_request', 'bsp_search_ajax_request' );
    //}



    //add_action("wp_footer", "bsp_inspect_add_styles");


}


bsp_inspect_init();



?>